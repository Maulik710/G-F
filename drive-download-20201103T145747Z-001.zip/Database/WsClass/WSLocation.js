
import React from 'react';
import { compare } from 'semver';

export default class WSLocation {
    
    Id= Number;
	LocationCode= String;
	LocationName= String;
	Latitude= String;
	Longitude= String;
	SeaLevel_InMetres= Number;
	FK_GeoMessage_Location= String;
    FK_Tickets_LocationCode= String;
   
    constructor() { }
}