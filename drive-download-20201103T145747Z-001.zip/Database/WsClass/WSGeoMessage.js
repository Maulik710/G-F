import React from 'react';
import { compare } from 'semver';

export default class WSGeoMessage {

    Id= Number;
    Message= String;
    UserName= String;
    UserTelephone= String;
    LocationCode= String;
    ValidityDateFrom= String;
    ValidityTimeFrom= String;
    ValidityDateTo= String;
    ValidityTimeTo= String;
   
    constructor() { }
}