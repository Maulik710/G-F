
import React from 'react';
import { compare } from 'semver';

export default class WSTicket {
    TicketNo= String;
	LocationCode= String;
	Date= String;
	Time= String;
	StatusUpdatedTime= String;
	Status= String;
	UserID=Number;
       
    constructor() { }
}