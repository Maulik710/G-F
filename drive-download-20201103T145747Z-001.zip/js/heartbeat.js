  
import { NativeModules } from 'react-native';

const { Heartbeat } = NativeModules;

export default Heartbeat;